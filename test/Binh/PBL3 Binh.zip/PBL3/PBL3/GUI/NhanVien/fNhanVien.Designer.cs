﻿namespace PBL3
{
    partial class fNhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fNhanVien));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnLichSu = new System.Windows.Forms.Button();
            this.btnDangXuat = new System.Windows.Forms.Button();
            this.btnTaiKhoan = new System.Windows.Forms.Button();
            this.btnTaoDon = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelNV = new System.Windows.Forms.Panel();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.flpBanAn = new System.Windows.Forms.FlowLayoutPanel();
            this.banAn12 = new System.Windows.Forms.Button();
            this.banAn11 = new System.Windows.Forms.Button();
            this.banAn10 = new System.Windows.Forms.Button();
            this.banAn9 = new System.Windows.Forms.Button();
            this.banAn8 = new System.Windows.Forms.Button();
            this.banAn7 = new System.Windows.Forms.Button();
            this.banAn6 = new System.Windows.Forms.Button();
            this.banAn5 = new System.Windows.Forms.Button();
            this.banAn4 = new System.Windows.Forms.Button();
            this.banAn3 = new System.Windows.Forms.Button();
            this.banAn2 = new System.Windows.Forms.Button();
            this.banAn1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelNV.SuspendLayout();
            this.flpBanAn.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnLichSu);
            this.panel1.Controls.Add(this.btnDangXuat);
            this.panel1.Controls.Add(this.btnTaiKhoan);
            this.panel1.Controls.Add(this.btnTaoDon);
            this.panel1.Controls.Add(this.btnHome);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(172, 535);
            this.panel1.TabIndex = 0;
            // 
            // btnLichSu
            // 
            this.btnLichSu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLichSu.Location = new System.Drawing.Point(12, 300);
            this.btnLichSu.Name = "btnLichSu";
            this.btnLichSu.Size = new System.Drawing.Size(147, 47);
            this.btnLichSu.TabIndex = 5;
            this.btnLichSu.Text = "Lịch sử";
            this.btnLichSu.UseVisualStyleBackColor = true;
            this.btnLichSu.Click += new System.EventHandler(this.btnLichSu_Click);
            // 
            // btnDangXuat
            // 
            this.btnDangXuat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangXuat.Location = new System.Drawing.Point(12, 465);
            this.btnDangXuat.Name = "btnDangXuat";
            this.btnDangXuat.Size = new System.Drawing.Size(147, 47);
            this.btnDangXuat.TabIndex = 7;
            this.btnDangXuat.Text = "Đăng xuất";
            this.btnDangXuat.UseVisualStyleBackColor = true;
            // 
            // btnTaiKhoan
            // 
            this.btnTaiKhoan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTaiKhoan.Location = new System.Drawing.Point(12, 382);
            this.btnTaiKhoan.Name = "btnTaiKhoan";
            this.btnTaiKhoan.Size = new System.Drawing.Size(147, 47);
            this.btnTaiKhoan.TabIndex = 6;
            this.btnTaiKhoan.Text = "Tài khoản";
            this.btnTaiKhoan.UseVisualStyleBackColor = true;
            this.btnTaiKhoan.Click += new System.EventHandler(this.btnTaiKhoan_Click);
            // 
            // btnTaoDon
            // 
            this.btnTaoDon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTaoDon.Location = new System.Drawing.Point(12, 222);
            this.btnTaoDon.Name = "btnTaoDon";
            this.btnTaoDon.Size = new System.Drawing.Size(147, 47);
            this.btnTaoDon.TabIndex = 2;
            this.btnTaoDon.Text = "Tạo đơn";
            this.btnTaoDon.UseVisualStyleBackColor = true;
            this.btnTaoDon.Click += new System.EventHandler(this.btnTaoDon_Click);
            // 
            // btnHome
            // 
            this.btnHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.Location = new System.Drawing.Point(12, 144);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(147, 47);
            this.btnHome.TabIndex = 1;
            this.btnHome.Text = "Trang chủ";
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(3, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(172, 126);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(172, 126);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panelNV
            // 
            this.panelNV.Controls.Add(this.flpBanAn);
            this.panelNV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelNV.Location = new System.Drawing.Point(172, 0);
            this.panelNV.Name = "panelNV";
            this.panelNV.Size = new System.Drawing.Size(918, 535);
            this.panelNV.TabIndex = 1;
            // 
            // flpBanAn
            // 
            this.flpBanAn.Controls.Add(this.banAn1);
            this.flpBanAn.Controls.Add(this.banAn2);
            this.flpBanAn.Controls.Add(this.banAn3);
            this.flpBanAn.Controls.Add(this.banAn4);
            this.flpBanAn.Controls.Add(this.banAn5);
            this.flpBanAn.Controls.Add(this.banAn6);
            this.flpBanAn.Controls.Add(this.banAn7);
            this.flpBanAn.Controls.Add(this.banAn8);
            this.flpBanAn.Controls.Add(this.banAn9);
            this.flpBanAn.Controls.Add(this.banAn10);
            this.flpBanAn.Controls.Add(this.banAn11);
            this.flpBanAn.Controls.Add(this.banAn12);
            this.flpBanAn.Location = new System.Drawing.Point(56, 56);
            this.flpBanAn.Name = "flpBanAn";
            this.flpBanAn.Size = new System.Drawing.Size(809, 431);
            this.flpBanAn.TabIndex = 1;
            // 
            // banAn12
            // 
            this.banAn12.Location = new System.Drawing.Point(606, 289);
            this.banAn12.Name = "banAn12";
            this.banAn12.Size = new System.Drawing.Size(195, 137);
            this.banAn12.TabIndex = 23;
            this.banAn12.Text = "Bàn 12";
            this.banAn12.UseVisualStyleBackColor = true;
            // 
            // banAn11
            // 
            this.banAn11.Location = new System.Drawing.Point(405, 289);
            this.banAn11.Name = "banAn11";
            this.banAn11.Size = new System.Drawing.Size(195, 137);
            this.banAn11.TabIndex = 22;
            this.banAn11.Text = "Bàn 11";
            this.banAn11.UseVisualStyleBackColor = true;
            // 
            // banAn10
            // 
            this.banAn10.Location = new System.Drawing.Point(204, 289);
            this.banAn10.Name = "banAn10";
            this.banAn10.Size = new System.Drawing.Size(195, 137);
            this.banAn10.TabIndex = 21;
            this.banAn10.Text = "Bàn 10";
            this.banAn10.UseVisualStyleBackColor = true;
            // 
            // banAn9
            // 
            this.banAn9.Location = new System.Drawing.Point(3, 289);
            this.banAn9.Name = "banAn9";
            this.banAn9.Size = new System.Drawing.Size(195, 137);
            this.banAn9.TabIndex = 20;
            this.banAn9.Text = "Bàn 9";
            this.banAn9.UseVisualStyleBackColor = true;
            // 
            // banAn8
            // 
            this.banAn8.Location = new System.Drawing.Point(606, 146);
            this.banAn8.Name = "banAn8";
            this.banAn8.Size = new System.Drawing.Size(195, 137);
            this.banAn8.TabIndex = 19;
            this.banAn8.Text = "Bàn 8";
            this.banAn8.UseVisualStyleBackColor = true;
            // 
            // banAn7
            // 
            this.banAn7.Location = new System.Drawing.Point(405, 146);
            this.banAn7.Name = "banAn7";
            this.banAn7.Size = new System.Drawing.Size(195, 137);
            this.banAn7.TabIndex = 18;
            this.banAn7.Text = "Bàn 7";
            this.banAn7.UseVisualStyleBackColor = true;
            // 
            // banAn6
            // 
            this.banAn6.Location = new System.Drawing.Point(204, 146);
            this.banAn6.Name = "banAn6";
            this.banAn6.Size = new System.Drawing.Size(195, 137);
            this.banAn6.TabIndex = 17;
            this.banAn6.Text = "Bàn 6";
            this.banAn6.UseVisualStyleBackColor = true;
            // 
            // banAn5
            // 
            this.banAn5.Location = new System.Drawing.Point(3, 146);
            this.banAn5.Name = "banAn5";
            this.banAn5.Size = new System.Drawing.Size(195, 137);
            this.banAn5.TabIndex = 16;
            this.banAn5.Text = "Bàn 5";
            this.banAn5.UseVisualStyleBackColor = true;
            // 
            // banAn4
            // 
            this.banAn4.Location = new System.Drawing.Point(606, 3);
            this.banAn4.Name = "banAn4";
            this.banAn4.Size = new System.Drawing.Size(195, 137);
            this.banAn4.TabIndex = 15;
            this.banAn4.Text = "Bàn 4";
            this.banAn4.UseVisualStyleBackColor = true;
            // 
            // banAn3
            // 
            this.banAn3.Location = new System.Drawing.Point(405, 3);
            this.banAn3.Name = "banAn3";
            this.banAn3.Size = new System.Drawing.Size(195, 137);
            this.banAn3.TabIndex = 14;
            this.banAn3.Text = "Bàn 3";
            this.banAn3.UseVisualStyleBackColor = true;
            // 
            // banAn2
            // 
            this.banAn2.Location = new System.Drawing.Point(204, 3);
            this.banAn2.Name = "banAn2";
            this.banAn2.Size = new System.Drawing.Size(195, 137);
            this.banAn2.TabIndex = 13;
            this.banAn2.Text = "Bàn 2";
            this.banAn2.UseVisualStyleBackColor = true;
            // 
            // banAn1
            // 
            this.banAn1.Location = new System.Drawing.Point(3, 3);
            this.banAn1.Name = "banAn1";
            this.banAn1.Size = new System.Drawing.Size(195, 137);
            this.banAn1.TabIndex = 12;
            this.banAn1.Text = "Bàn 1";
            this.banAn1.UseVisualStyleBackColor = true;
            // 
            // fNhanVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(1090, 535);
            this.Controls.Add(this.panelNV);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.Name = "fNhanVien";
            this.Text = "fNhanVien";
            this.Load += new System.EventHandler(this.fNhanVien_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelNV.ResumeLayout(false);
            this.flpBanAn.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnDangXuat;
        private System.Windows.Forms.Button btnTaiKhoan;
        private System.Windows.Forms.Button btnTaoDon;
        private System.Windows.Forms.Button btnLichSu;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Panel panelNV;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.FlowLayoutPanel flpBanAn;
        private System.Windows.Forms.Button banAn1;
        private System.Windows.Forms.Button banAn2;
        private System.Windows.Forms.Button banAn3;
        private System.Windows.Forms.Button banAn4;
        private System.Windows.Forms.Button banAn5;
        private System.Windows.Forms.Button banAn6;
        private System.Windows.Forms.Button banAn7;
        private System.Windows.Forms.Button banAn8;
        private System.Windows.Forms.Button banAn9;
        private System.Windows.Forms.Button banAn10;
        private System.Windows.Forms.Button banAn11;
        private System.Windows.Forms.Button banAn12;
    }
}