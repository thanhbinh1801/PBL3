﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBL3.DAL
{
    public enum TrangThaiMonAn
    {
        Con, //0
        Het, //1
        DangCheBien, //2
        DaCheBien, //3
    }
}
