﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBL3.DAL
{
    public enum PhanQuyen
    {
        QuanLy, //0
        DauBep, //1
        NhanVien //2
    }
}
